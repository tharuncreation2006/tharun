// Preloader

window.addEventListener("load", function(){
    const preloader = document.getElementById("preloader");
    setTimeout(function(){
        preloader.classList.add("hidden");
    }, 600);
});


// Contact Form

const contactForm = document.getElementById("contactForm");
const submitBtn = document.getElementById("submitBtn");
const btnText = submitBtn.querySelector(".btn-text");

contactForm.addEventListener("submit", function(e){

    e.preventDefault();

    // Show loading state
    submitBtn.disabled = true;
    btnText.textContent = "Sending";
    const spinner = document.createElement("span");
    spinner.classList.add("btn-spinner");
    submitBtn.appendChild(spinner);

    setTimeout(function(){
        spinner.remove();
        submitBtn.disabled = false;
        btnText.textContent = "Send Message";

        alert("Message Sent Successfully 🚀");

        contactForm.reset();
    }, 1200);
});


// AI Floating Particles

const particlesContainer =
document.getElementById("particles");

for(let i = 0; i < 120; i++){

    const particle =
    document.createElement("div");

    particle.classList.add("particle");

    const size =
    Math.random() * 5 + 2;

    particle.style.width =
    size + "px";

    particle.style.height =
    size + "px";

    particle.style.left =
    Math.random() * 100 + "%";

    particle.style.animationDuration =
    (Math.random() * 15 + 8) + "s";

    particle.style.animationDelay =
    (Math.random() * 10) + "s";

    particlesContainer.appendChild(particle);
}


// Scroll Reveal Animation

const revealEls = document.querySelectorAll(".fade-up");

const revealObserver = new IntersectionObserver(function(entries){

    entries.forEach(function(entry){

        if(entry.isIntersecting){
            entry.target.classList.add("visible");
        }
    });

}, { threshold: 0.15 });

revealEls.forEach(function(el){
    revealObserver.observe(el);
});


// Background Music Toggle

const bgMusic = document.getElementById("bgMusic");
const musicToggle = document.getElementById("musicToggle");
const musicIcon = document.getElementById("musicIcon");

let isPlaying = false;

musicToggle.addEventListener("click", function(){

    if(isPlaying){
        bgMusic.pause();
        musicIcon.textContent = "🔇";
        musicToggle.classList.remove("playing");
        isPlaying = false;
    } else {
        musicToggle.classList.add("loading");
        bgMusic.volume = 0.5;
        bgMusic.play().then(function(){
            musicToggle.classList.remove("loading");
            musicIcon.textContent = "🔊";
            musicToggle.classList.add("playing");
            isPlaying = true;
        }).catch(function(err){
            console.log("Add your mp3 file to the audio folder:", err);
            musicToggle.classList.remove("loading");
        });
    }
});